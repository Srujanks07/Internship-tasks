
-- 1. Select all customers from North region
SELECT * FROM customers WHERE region = 'North';

-- 2. Count total customers per region
SELECT region, COUNT(*) AS total_customers FROM customers GROUP BY region;

-- 3. Join orders with customers to get order info with customer names
SELECT o.order_id, c.name, o.order_date, o.total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id;

-- 4. Join products and order_items to get total sales per category
SELECT p.category, SUM(oi.quantity * oi.price) AS total_sales
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.category
ORDER BY total_sales DESC;

-- 5. Subquery: Find customers who placed orders over 1000
SELECT name FROM customers
WHERE customer_id IN (
  SELECT customer_id FROM orders WHERE total_amount > 1000
);

-- 6. Create a view for total category sales
CREATE VIEW category_sales AS
SELECT p.category, SUM(oi.quantity * oi.price) AS total_sales
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.category;

-- 7. Aggregate: Average order amount per customer
SELECT c.name, AVG(o.total_amount) AS avg_order_amount
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id;

-- 8. Join orders with payments to get order payment info
SELECT o.order_id, o.total_amount, p.payment_method, p.amount
FROM orders o
JOIN payments p ON o.order_id = p.order_id;
